
EmaxSigmoid<-function(c,parm=parm){
  Emax=parm[1]
  ED50=parm[2]
  gamma=parm[3]
  Emax*c^gamma/(ED50^gamma+c^gamma)
}




