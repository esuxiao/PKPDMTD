

MCMCIVEmax<-function(data,initial=NULL,priorFun=NULL,regimeList=regimeList,
                     MCMCSetting=MCMCSetting,fixGamma=FALSE){ 
  #browser()
  if(!fixGamma){
    if(is.null(priorFun)) priorFun<-function(parm) sum(dgamma(parm[1],shape=1.17,scale=2.92,log=TRUE)+dgamma(parm[2],shape=1,scale=3,log=TRUE)+dgamma(parm[3],shape=1.86,scale=2.31,log=TRUE)+
                                   dgamma(parm[4],shape=1,scale=3.15,log=TRUE)+dgamma(parm[5],shape=1.73,scale=1.69,log=TRUE)+dgamma(parm[6],shape=1.45,scale=2.59,log=TRUE),na.rm=TRUE)
    logDens<-function(parm) logLik(data,parmPK=parm[2:3],parmPD=parm[4:6],sigmaPK=parm[1],regimeList=regimeList)+priorFun(parm)
    if(is.null(initial)) initial=rep(0.5,6)
    Fit_Slice(logpost=logDens,initial=initial,names=c("sigmaPK","k10","Vc","Emax","ED50","gamma"),
                update=MCMCSetting$update,thin=MCMCSetting$thin,start=MCMCSetting$start)
  } else {
    if(is.null(priorFun)) priorFun<-function(parm) sum(dgamma(parm[1],shape=1.17,scale=2.92,log=TRUE)+dgamma(parm[2],shape=1,scale=3,log=TRUE)+dgamma(parm[3],shape=1.86,scale=2.31,log=TRUE)+
                                                         dgamma(parm[4],shape=1,scale=3.15,log=TRUE)+dgamma(parm[5],shape=1.73,scale=1.69,log=TRUE),na.rm=TRUE)
    logDens<-function(parm) logLik(data,parmPK=parm[2:3],parmPD=c(parm[4:5],1),sigmaPK=parm[1],regimeList=regimeList)+priorFun(parm)  
    if(is.null(initial)) initial=rep(0.5,5)
    Fit_Slice(logpost=logDens,initial=initial,names=c("sigmaPK","k10","Vc","Emax","ED50"),
              update=MCMCSetting$update,thin=MCMCSetting$thin,start=MCMCSetting$start)
  }
}

Fit_Slice<-function(logpost=logpost,logDensGradName=NULL,initial=initial,
                   update=10000,thin=1,start=1,names=NULL,method="slice",
                   theta=1,tuning=1,use.gradient=FALSE){
  ndim=length(initial)
  samples=NULL
  #browser()
  ####make log target distribution
  logDensGrad<-function(parm) {
    res=try(numDeriv::grad(logpost,parm),silent=TRUE)
    if(class(logpost)=="try-error") rep(0,length(parm)) else res
  }
  target=SamplerCompare::make.dist(ndim, 'target',log.density=logpost,grad.log.density=logDensGrad)
  if(method=="slice") samples=try(coda::mcmc(SamplerCompare::hyperrectangle.sample(target, initial, update,use.gradient=use.gradient)$X),silent=FALSE)
  if(method=="oblique") samples=try(coda::mcmc(SamplerCompare::oblique.hyperrect.sample(target, initial, update)$X),silent=TRUE) 
  if(method=="covmatch") samples=try(coda::mcmc(SamplerCompare::cov.match.sample(target, initial, update, theta=theta,tuning=tuning)$X),silent=TRUE)
  if(method=="MH") samples=try(coda::mcmc(SamplerCompare::adaptive.metropolis.sample(target, initial, update, tuning=tuning)$X),silent=TRUE)
  last=nrow(samples)
  res=window(samples, start, last, thin)
  if(!is.null(names)) colnames(res)=names
  res
}