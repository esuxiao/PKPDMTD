

EVSingleDose<-function(t,parm=parm,dose=dose){
  k10=parm[1]
  ka=parm[2]
  Vc=parm[3]
  ka*dose/(Vc*(ka-k10))*(exp(-k10*t)-exp(-ka*t))
}

Logistic5Parameters<-function(c,parm=parm){
  beta1=parm[1]
  beta3=parm[2]
  beta4=parm[3]
  beta5=parm[4]
  (beta1)/(1+(c/beta3)^beta4)^beta5
}


EVMultipleDose<-function(TimePoint,AdmTime=AdmTime,dose=dose,parm=parm){
  if(length(TimePoint)==1){
    indicator=(TimePoint-AdmTime)>=0
    return(sum(EVSingleDose(TimePoint-AdmTime,parm=parm,dose=dose)*indicator,na.rm=TRUE))
  } else {
    indicatorFun<-function(TimePoint,AdmTime=AdmTime) (TimePoint-AdmTime)>0
    indicator=mapply(indicatorFun,TimePoint,MoreArgs=list(AdmTime=AdmTime))
    Timeindex=t(outer(TimePoint,AdmTime,"-"))
    return(colSums(EVSingleDose(Timeindex,parm=parm,dose=dose)*indicator,na.rm=TRUE))
  }
}

EVLogisticInstant<-function(TimePoint,parmPK=parmPK,parmPD=parmPD,
                        dose=dose,AdmTime=AdmTime,model=model){
  # browser()
  conc=EVMultipleDose(TimePoint,AdmTime=AdmTime,dose=dose,parm=parmPK)
  if(model=="logistic") return(Logistic5Parameters(conc,parm=parmPD))
  if(model=="linear")  return(conc*parmPD)
}


EVLogisticCumEffectMultipleDose<-function(TimePoint,dose=dose,AdmTime=AdmTime,parmPD=parmPD,
  parmPK=parmPK,model=model){
  if(length(TimePoint)==1) return(integrate(EVLogisticInstant,0,TimePoint,parmPK=parmPK,parmPD=parmPD,
            dose=dose,AdmTime=AdmTime,model=model)$value) 
  if(length(TimePoint)>1) return(sapply(TimePoint, function(t) integrate(EVLogisticInstant,0,t,parmPK=parmPK,parmPD=parmPD,
                                                                  dose=dose,AdmTime=AdmTime,model=model)$value))
}

ProbEndpointEVLogistic<-function(TimePoint,parmPK=parmPK,parmPD=parmPD,
                                 dose=dose,AdmTime=AdmTime,model=model){
  1-exp(EVLogisticCumEffectMultipleDose(TimePoint,dose=dose,AdmTime=AdmTime,
                                        parmPD=parmPD,parmPK=parmPK,model=model)*(-1))
  

}

DoseFindEVLogistic<-function(toxicity,AdmTime,parmlist=parmlist,EndpointTime=EndpointTime,interval=c(0.001,10),model=model){
  equationfun<-function(dose,prob=prob) ProbEndpointEVLogistic(EndpointTime,AdmTime=AdmTime,dose=rep(dose,length(AdmTime)),
                              parmPD=parmlist$parmPD,parmPK=parmlist$parmPK,model=model)-prob
  dosefun<-function(prob) uniroot(equationfun,interval=interval,prob=prob)$root
  dosefun(toxicity)
}