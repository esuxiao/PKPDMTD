
SetRegimenList<-function(TotoalDose,Schedule){
	RegimenList=list()
	Ndose=length(TotoalDose)
	NAdm=length(Schedule)
	for(i in 1:Ndose){
		AdmTime=Schedule
		dose=rep(TotoalDose[i]/NAdm,NAdm)
		RegimenList[[i]]=data.frame(AdmTime,dose)
	}
	RegimenList
}

SetData<-function(data,followup){
  datain=plyr::rename(data,c("subject"="Subject","visit"="Visit","dose"="regime","toxicity"="Endpoints","time"="PKTime","conc"="PKobs"))
  datain$EndpointTime=rep(followup,nrow(datain))
  datain=plyr::arrange(datain,datain$Subject,datain$Visit)
  return(split(datain,f=datain$Subject))
}




 


 ######
DoseFindIVEmax<-function(toxicity,AdmTime,parmlist=parmlist,EndpointTime=EndpointTime,interval=c(0.001,10)){
   equationfun<-function(dose,prob=prob) ProbEndpoint(EndpointTime,AdmTime=AdmTime,dose=rep(dose,length(AdmTime)),
               parmPD=parmlist$parmPD,parmPK=parmlist$parmPK)-prob
   dosefun<-function(prob) uniroot(equationfun,interval=interval,prob=prob)$root
   dosefun(toxicity)
}



