






NextLevel<-function(data,TotoalDose,Schedule,CurrentDose,setting){
  control=NULL
  ####################################
  ## Setting
  ####################################
  rule=setting$rule
  if(!rule%in%c("mTPI","tox")) {stop("Only two decision rules available: mTPI or tox!")}
  followup=setting$followup
  target=setting$target
  psi1=setting$psi1
  psi2=setting$psi2
  if(rule=="mTPI"){
    eps1=setting$eps1
    eps2=setting$eps2
  }
  eps1=setting$eps1
  eps2=setting$eps2
  if(is.null(control$priorFun)){
    priorFun<-function(parm) sum(dunif(parm[1],min=0,max=100,log=TRUE)+
                                   dunif(parm[2],min=0,max=100,log=TRUE)+
                                   dunif(parm[3],min=0,max=100,log=TRUE)+ 
                                   dunif(parm[4],min=0,max=100,log=TRUE)+
                                   dunif(parm[5],min=0,max=100,log=TRUE)+
                                   dunif(parm[6],min=-5,max=5,log=TRUE),
                                 na.rm=TRUE)
  }
  #####
  if(is.null(control$MCMCSetting)){
    MCMCSetting=list(method="slice",update=5000,thin=1,start=1000)
  } else MCMCSetting=control$MCMCSetting
  #####
  if(is.null(control$initial)){
    initial=rep(0.1,6)
  } else {initial=control$initial}
  names(initial)=c("sigmaPK","k10","Vc","Emax","ED50","gamma")
  ################################
  ## re-format the data
  ##############################
  regimeList=SetRegimenList(TotoalDose,Schedule)
  datin=SetData(data,followup)
  Ndose=length(TotoalDose)
  ###############################
  ##  Fit the model
  ###############################
  Fit=MCMCIVEmax(datin,initial=initial,priorFun,regimeList=regimeList,
                 MCMCSetting=MCMCSetting)
  #################################
  ## Calculate the relative quantity
  #################################
  probSafe=CIdens=MeanTox=rep(NA,Ndose)
  for(level in 1:Ndose){
    ToxDis=sapply(1:nrow(Fit),function(r) ProbEndpoint(followup,AdmTime=regimeList[[level]]$AdmTime,
                                                       dose=regimeList[[level]]$dose,parmPD=Fit[r,4:6],
                                                       parmPK=Fit[r,2:3]))
    probSafe[level]=mean(ToxDis<=target,na.rm=TRUE)
    MeanTox[level]=mean(ToxDis,na.rm=TRUE)
    if(rule=="mTPI")CIdens[level]=mean((ToxDis<=(target+eps2))&(ToxDis>=(target-eps1)),na.rm=TRUE)/(eps1+eps2) else CIdens[level]=NA
  }
  ###############################
  ## Find the next  level #######
  ###############################
  maxilevel=max(data$dose)
  if(rule=="mTPI"){
    if(all(CIdens==0)) whichMaxCI=which.min(abs(MeanTox-target)) else whichMaxCI=which.max(CIdens)
    if(whichMaxCI>maxilevel)   Nextdose=CurrentDose+1   ##escalate  
    if(whichMaxCI<=maxilevel)  Nextdose=whichMaxCI   ## de-escalate
    if(probSafe[1]<psi1) Nextdose=NA
  }
  if(rule=="tox"){
    whichMaxCI=which.min(abs(MeanTox-target)) 
    if(whichMaxCI>maxilevel)   Nextdose=CurrentDose+1   ##escalate  
    if(whichMaxCI<=maxilevel)  Nextdose=whichMaxCI   ## de-escalate
    if(probSafe[1]<psi1) Nextdose=NA
  }
  ###return
  return(list(probSafe=probSafe,MeanTox=MeanTox,CIdens=CIdens,NextDoselevel=Nextdose))

}



SelectMTD<-function(data,TotoalDose,Schedule,setting){
  control=NULL
  rule=setting$rule
  if(!rule%in%c("mTPI","tox")) {stop("Only two decision rules available: mTPI or tox!")}
  ####################################
  ## Setting
  ####################################
  followup=setting$followup
  target=setting$target
  psi1=setting$psi1
  psi2=setting$psi2
  if(rule=="mTPI"){
    eps1=setting$eps1
    eps2=setting$eps2
  }
  if(is.null(control$priorFun)){
    priorFun<-function(parm) sum(dunif(parm[1],min=0,max=100,log=TRUE)+
                                   dunif(parm[2],min=0,max=100,log=TRUE)+
                                   dunif(parm[3],min=0,max=100,log=TRUE)+ 
                                   dunif(parm[4],min=0,max=100,log=TRUE)+
                                   dunif(parm[5],min=0,max=100,log=TRUE)+
                                   dunif(parm[6],min=-5,max=5,log=TRUE),
                                 na.rm=TRUE)
  }
  #####
  if(is.null(control$MCMCSetting)){
    MCMCSetting=list(method="slice",update=5000,thin=1,start=1000)
  } else MCMCSetting=control$MCMCSetting
  #####
  if(is.null(control$initial)){
    initial=rep(0.1,6)
  } else {initial=control$initial}
  names(initial)=c("sigmaPK","k10","Vc","Emax","ED50","gamma")
  ################################
  ## re-format the data
  ##############################
  regimeList=SetRegimenList(TotoalDose,Schedule)
  datin=SetData(data,followup)
  Ndose=length(TotoalDose)
  ###############################
  ##  Fit the model
  ###############################
  Fit=MCMCIVEmax(datin,initial=initial,priorFun,regimeList=regimeList,
                 MCMCSetting=MCMCSetting)
  #################################
  ## Calculate the relative quantity
  #################################
  probSafe=CIdens=MeanTox=rep(NA,Ndose)
  for(level in 1:Ndose){
    ToxDis=sapply(1:nrow(Fit),function(r) ProbEndpoint(followup,AdmTime=regimeList[[level]]$AdmTime,
                                                       dose=regimeList[[level]]$dose,parmPD=Fit[r,4:6],
                                                       parmPK=Fit[r,2:3]))
    probSafe[level]=mean(ToxDis<=target,na.rm=TRUE)
    MeanTox[level]=mean(ToxDis,na.rm=TRUE)
    if(rule=="mTPI")CIdens[level]=mean((ToxDis<=(target+eps2))&(ToxDis>=(target-eps1)),na.rm=TRUE)/(eps1+eps2) else CIdens[level]=NA
  }
  SafeIndex=probSafe>=psi2
  ###############################
  ## Select the MTD #######
  ###############################
  maxilevel=max(data$dose)
  leveltried=unique(data$dose)
  highestSafe=sum(SafeIndex)
  CIdensSafe=ifelse(SafeIndex,CIdens,-Inf)
  if(maxilevel<Ndose) CIdensSafe[maxilevel:Ndose]=-Inf
  maxCIdensSafe=which.max(CIdensSafe)
  probmeanSafe=ifelse(SafeIndex,MeanTox,-Inf)
  if(maxilevel<Ndose) probmeanSafe[maxilevel:Ndose]=-Inf
  difSafe=abs(probmeanSafe-target)
  if(rule=="mTPI"){
    if(highestSafe==0) {
      cat("\n No safe dose level. The trial is inconclusive.\n")
      MTD=NA  
    }  else{
      MTD=ifelse(all(CIdensSafe==0),which.min(difSafe),maxCIdensSafe)
    }
  } 
  if(rule=="tox"){
    if(highestSafe==0) {
      cat("\n No safe dose level. The trial is inconclusive.\n")
      MTD=NA  
    }  else{
      MTD=which.min(difSafe)
    }
  }
  return(list(probSafe=probSafe,MeanTox=MeanTox,CIdens=CIdens,MTD=MTD))
}