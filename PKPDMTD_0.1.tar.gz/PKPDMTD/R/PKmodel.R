

IVSingleDose<-function(t,parm=parm,dose=dose){
	k10=parm[1]
	Vc=parm[2]
  dose/Vc*exp(-k10*t)
}



IVMultipleDose<-function(TimePoint,AdmTime=AdmTime,dose=dose,parm=parm){
  if(length(TimePoint)==1){
    indicator=(TimePoint-AdmTime)>=0
    return(sum(IVSingleDose(TimePoint-AdmTime,parm=parm,dose=dose)*indicator,na.rm=TRUE))
  } else {
    indicatorFun<-function(TimePoint,AdmTime=AdmTime) (TimePoint-AdmTime)>0
    indicator=mapply(indicatorFun,TimePoint,MoreArgs=list(AdmTime=AdmTime))
    Timeindex=t(outer(TimePoint,AdmTime,"-"))
    return(colSums(IVSingleDose(Timeindex,parm=parm,dose=dose)*indicator,na.rm=TRUE))
  }
}

