


logLikPK<-function(dat,regimeList=regimeList,parmPK=parmPK,sigmaPK=sigmaPK){
#  browser() 
  if(any(c(parmPK,sigmaPK)<0)) return(-Inf)
  Nregime=length(dat)
  multiden<-function(i) {
    regime=unique(dat[[i]]$regime)
    dose=regimeList[[regime]]$dose
    AdmTime=regimeList[[regime]]$AdmTime
    dat[[i]]$residual=dat[[i]]$PKobs-IVMultipleDose(dat[[i]]$PKTime,AdmTime=AdmTime,
                                    dose=dose,parm=parmPK) 

    sum(dnorm(dat[[i]]$residual,sd=sigmaPK,log=TRUE),na.rm=TRUE)
  }
  
  logLi=unlist(sapply(1:Nregime,multiden,simplify=FALSE))
  logLik=sum(logLi,na.rm=TRUE)
  logLik  
}

logLikOutcomeGivenPKPD<-function(dat,parmPK=parmPK,parmPD=parmPD,regimeList=regimeList){
  Nregime=length(dat)
  if(any(c(parmPD,parmPK)<0)) return(-Inf)
  myfun<-function(i) {
    temp2=dat[[i]]
    temp1=subset(temp2,temp2$Visit==1)
    regime=unique(temp1$regime)
    dose=regimeList[[regime]]$dose
    AdmTime=regimeList[[regime]]$AdmTime
    CumEffect=CumEffectMultipleDose(temp1$EndpointTime,AdmTime=AdmTime,
                                    dose=dose,parmPD=parmPD,parmPK=parmPK)
    MeanEndpoints=1-exp(CumEffect*(-1))
    log(ifelse(temp1$Endpoints==1,MeanEndpoints,1-MeanEndpoints))
  }
  logLi=unlist(sapply(1:Nregime,myfun,simplify=FALSE))
	sum(logLi,na.rm=TRUE)
}


logLik<-function(dat,parmPK=parmPK,parmPD=parmPD,sigmaPK=sigmaPK,
                 regimeList=regimeList){
  if(any(c(sigmaPK,parmPD,parmPK)<0)) return(-Inf)
  logL_EndpointGivenPKPD=logLikOutcomeGivenPKPD(dat,parmPK=parmPK,parmPD=parmPD,
                                                regimeList=regimeList)
  logL_PK=logLikPK(dat,regimeList=regimeList,parmPK=parmPK,sigmaPK=sigmaPK)
  logL_EndpointGivenPKPD+logL_PK
}


