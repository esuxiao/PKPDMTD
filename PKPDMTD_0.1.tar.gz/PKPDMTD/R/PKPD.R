
IVEmaxInstant<-function(TimePoint,parmPK=parmPK,parmPD=parmPD,
                         dose=dose,AdmTime=AdmTime){
 # browser()
	conc=IVMultipleDose(TimePoint,AdmTime=AdmTime,dose=dose,parm=parmPK)
	EmaxSigmoid(conc,parm=parmPD)
 }

CumEffectOneDose<-function(TimePoint,dose=dose,parmPD=parmPD,parmPK=parmPK){
	Emax=parmPD[1]
	ED50=parmPD[2]
	gamma=parmPD[3]
	k10=parmPK[1]
	Vc=parmPK[2]
	Emax/(gamma*k10)*(log(ED50^gamma+(dose/Vc)^gamma)-log(ED50^gamma+((dose*exp(-k10*TimePoint))/Vc)^gamma))
}

##
LastAdmTimeIndex<-function(TimePoint,AdmTime) sum((TimePoint>=AdmTime))
##
LastAdmTimeIndexVec<-function(TimePoint,AdmTime) mapply(function(TimePoint,AdmTime=AdmTime) sum((TimePoint>=AdmTime)),TimePoint,MoreArgs=list(AdmTime=AdmTime)) 
##
IndefiniteIntegral<-function(TimePoint,dose=dose,AdmTime=AdmTime,parmPD=parmPD,parmPK=parmPK) {
  Emax=parmPD[1]
  ED50=parmPD[2]
  gamma=parmPD[3]
  k10=parmPK[1]
  Vc=parmPK[2]
	indicator=TimePoint>=AdmTime
	-Emax/(gamma*k10)*log(ED50^gamma+(sum(dose*exp(-(k10*(TimePoint-AdmTime)))*indicator)/Vc)^gamma)
}
###
FixedPartFun<-function(i,dose=dose,AdmTime=AdmTime,parmPD=parmPD,parmPK=parmPK,esp=1e-5)
   ifelse(i>0,IndefiniteIntegral(AdmTime[i+1]-esp,dose=dose,AdmTime=AdmTime,parmPD=parmPD,parmPK=parmPK)-
            IndefiniteIntegral(AdmTime[i],dose=dose,AdmTime=AdmTime,parmPD=parmPD,parmPK=parmPK),0)
###
CumEffectMultipleDose<-function(TimePoint,AdmTime=AdmTime,
                         dose=dose,parmPD=parmPD,parmPK=parmPK){
  Emax=parmPD[1]
  ED50=parmPD[2]
  gamma=parmPD[3]
  k10=parmPK[1]
  Vc=parmPK[2]
  #browser()
	if(length(TimePoint)==1){
		LastAdmTimei=LastAdmTimeIndex(TimePoint,AdmTime)
		LastPart=IndefiniteIntegral(TimePoint,dose=dose,AdmTime=AdmTime,parmPD=parmPD,parmPK=parmPK)-
              IndefiniteIntegral(AdmTime[LastAdmTimei],dose=dose,AdmTime=AdmTime,parmPD=parmPD,parmPK=parmPK)
		if(LastAdmTimei>1){
		  #FixedPartFun(i,dose=dose,AdmTime=AdmTime)
			FixedPart=sapply(0:(LastAdmTimei-1),FixedPartFun,dose=dose,AdmTime=AdmTime,parmPD=parmPD,parmPK=parmPK)
			Int=LastPart+sum(FixedPart,na.rm=TRUE)
		}	else Int=LastPart
	} else{
		LastAdmTimei=LastAdmTimeIndexVec(TimePoint,AdmTime)
		FixedPart=sapply(0:max(LastAdmTimei-1),FixedPartFun,dose=dose,AdmTime=AdmTime,parmPD=parmPD,parmPK=parmPK)   
		LastPart=sapply(TimePoint,IndefiniteIntegral,dose=dose,AdmTime=AdmTime,parmPD=parmPD,parmPK=parmPK)-
		  sapply(AdmTime[LastAdmTimei],IndefiniteIntegral,dose=dose,AdmTime=AdmTime,parmPD=parmPD,parmPK=parmPK)
		FixPartSelect=sapply(LastAdmTimei,seq,from=1,simplify=FALSE)
		Int=LastPart+unlist(lapply(FixPartSelect,function(element,FixedPart=FixedPart) sum(FixedPart[element]), FixedPart=FixedPart ))
	}
	Int
  
}
ProbEndpoint<-function(TimePoint,AdmTime=AdmTime,dose=dose,parmPD=parmPD,parmPK=parmPK){
  1-exp(CumEffectMultipleDose(TimePoint,AdmTime=AdmTime,
                              dose=dose,parmPD=parmPD,parmPK=parmPK)*(-1))
}



